
# Student Retention Prediction Project

## Overview
This project aims to predict student retention likelihood based on their performance and behavior metrics.

## Structure
- `data/`: Original and cleaned datasets
- `notebooks/`: Analysis and modeling scripts
- `output/`: Trained model and visualizations

## Tools
- Python (pandas, sklearn)
- Jupyter Notebook
- joblib (model persistence)
