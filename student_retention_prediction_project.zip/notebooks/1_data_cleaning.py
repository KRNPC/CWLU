/// 1_data_cleaning.ipynb
# 数据清洗与探索分析

import pandas as pd

# 读取数据
df = pd.read_csv('../data/student_data.csv')

# 查看基本信息
print(df.info())
print(df.describe())

# 缺失值检查
print(df.isnull().sum())

# 编码性别
df['gender'] = df['gender'].map({"Male": 1, "Female": 0})

# 保存清洗后数据
df.to_csv('../data/student_data_cleaned.csv', index=False)
print("✅ 清洗完成并保存")
