
# 可视化分析
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('../data/cleaned_student_data.csv')

# 箱线图：成绩 vs 是否续课
plt.figure(figsize=(8, 6))
sns.boxplot(x='retention', y='final_exam_score', data=df)
plt.title('Final Exam Score by Retention')
plt.savefig('../output/charts/final_exam_vs_retention.png')
plt.show()

# 热力图
plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title('Feature Correlation Heatmap')
plt.savefig('../output/charts/heatmap.png')
plt.show()
