/// 3_model_training.ipynb
# 预测模型构建与评估

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import joblib

# 读取数据
df = pd.read_csv('../data/student_data_cleaned.csv')

# 特征与目标
X = df[['age', 'gender', 'attendance_rate', 'homework_completion',
        'pre_test_score', 'mid_term_score', 'final_exam_score']]
y = df['retention']

# 切分数据
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 模型训练
clf = RandomForestClassifier(random_state=42)
clf.fit(X_train, y_train)

# 模型评估
y_pred = clf.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))

# 保存模型
joblib.dump(clf, '../output/final_model.pkl')
print("✅ 模型已保存")
